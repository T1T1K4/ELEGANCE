import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export const useCartStore = defineStore('cart', () => {
  const items = ref([]);

  function addToCart(product) {
    const existing = items.value.find(i => i.id === product.id);
    if (existing) {
      existing.quantity++;
    } else {
      items.value.push({ ...product, quantity: 1 });
    }
  }

  function removeFromCart(productId) {
    items.value = items.value.filter(i => i.id !== productId);
  }

  function updateQuantity(productId, quantity) {
    const item = items.value.find(i => i.id === productId);
    if (item) {
      item.quantity = quantity > 0 ? quantity : 1;
    }
  }

  const totalItems = computed(() => items.value.reduce((sum, i) => sum + i.quantity, 0));

  const totalPrice = computed(() => items.value.reduce((sum, i) => sum + i.price * i.quantity, 0).toFixed(2));

  return { items, addToCart, removeFromCart, updateQuantity, totalItems, totalPrice };
});
