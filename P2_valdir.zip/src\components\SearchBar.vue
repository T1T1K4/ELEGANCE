<template>
  <input
    type="text"
    placeholder="Buscar produtos..."
    class="w-full border p-2 rounded mb-4 md:mb-0 md:w-1/2"
    v-model="searchTerm"
    @input="onInput"
  />
</template>

<script setup>
import { ref } from 'vue';
import { debounce } from 'lodash';
const emit = defineEmits(['search']);
const searchTerm = ref('');

const debouncedSearch = debounce(() => {
  emit('search', searchTerm.value.trim());
}, 300);

function onInput() {
  debouncedSearch();
}
</script>
