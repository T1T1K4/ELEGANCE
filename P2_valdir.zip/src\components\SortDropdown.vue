<template>
  <select v-model="selected" @change="onChange" class="border p-2 rounded mb-4 md:mb-0 md:w-1/4">
    <option value="">Ordenar por</option>
    <option value="price-asc">Preço: Crescente</option>
    <option value="price-desc">Preço: Decrescente</option>
    <option value="name-asc">Nome: A-Z</option>
    <option value="name-desc">Nome: Z-A</option>
  </select>
</template>

<script setup>
import { ref } from 'vue';
const emit = defineEmits(['sortChange']);
const selected = ref('');

function onChange() {
  emit('sortChange', selected.value);
}
</script>
