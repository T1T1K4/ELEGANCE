<template>
  <footer class="bg-white text-[#2c3e50] py-12 mt-12 border-t border-[#ecf0f1]">
    <div class="container mx-auto px-4">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <h3 class="text-xl font-light tracking-wide mb-6 text-[#2c3e50]">Sobre Nós</h3>
          <p class="text-[#7f8c8d] leading-relaxed">
            Sua loja online de confiança para encontrar os melhores produtos com os melhores preços.
          </p>
        </div>
        <div>
          <h3 class="text-xl font-light tracking-wide mb-6 text-[#2c3e50]">Links Úteis</h3>
          <ul class="space-y-3">
            <li><a href="#" class="text-[#7f8c8d] hover:text-[#2c3e50] transition-colors duration-300">Política de Privacidade</a></li>
            <li><a href="#" class="text-[#7f8c8d] hover:text-[#2c3e50] transition-colors duration-300">Termos de Uso</a></li>
            <li><a href="#" class="text-[#7f8c8d] hover:text-[#2c3e50] transition-colors duration-300">FAQ</a></li>
            <li><a href="#" class="text-[#7f8c8d] hover:text-[#2c3e50] transition-colors duration-300">Contato</a></li>
          </ul>
        </div>
        <div>
          <h3 class="text-xl font-light tracking-wide mb-6 text-[#2c3e50]">Contato</h3>
          <ul class="space-y-3 text-[#7f8c8d]">
            <li class="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              contato@loja.com
            </li>
            <li class="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              (11) 9999-9999
            </li>
            <li class="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Rua Exemplo, 123
            </li>
          </ul>
        </div>
      </div>
      <div class="border-t border-[#ecf0f1] mt-12 pt-8 text-center text-[#7f8c8d]">
        <p>&copy; 2024 ELEGANCE. Todos os direitos reservados.</p>
      </div>
    </div>
  </footer>
</template>

<script setup>
// Componente Footer
</script> 