<template>
  <div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Carrinho de Compras</h1>
    <div v-if="items.length === 0">Seu carrinho está vazio.</div>
    <table v-else class="w-full mb-4 table-auto border-collapse border border-gray-300">
      <thead>
        <tr class="bg-gray-100">
          <th class="border border-gray-300 p-2 text-left">Produto</th>
          <th class="border border-gray-300 p-2">Preço</th>
          <th class="border border-gray-300 p-2">Quantidade</th>
          <th class="border border-gray-300 p-2">Subtotal</th>
          <th class="border border-gray-300 p-2">Ações</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id" class="border border-gray-300">
          <td class="border border-gray-300 p-2 flex items-center gap-2">
            <img :src="item.thumbnail" alt="" class="w-16 rounded" />
            {{ item.title }}
          </td>
          <td class="border border-gray-300 p-2 text-center">${{ item.price }}</td>
          <td class="border border-gray-300 p-2 text-center">
            <input
              type="number"
              min="1"
              v-model.number="item.quantity"
              @change="updateQuantity(item.id, item.quantity)"
              class="w-16 text-center border border-gray-300 rounded"
            />
          </td>
          <td class="border border-gray-300 p-2 text-center">${{ (item.price * item.quantity).toFixed(2) }}</td>
          <td class="border border-gray-300 p-2 text-center">
            <button @click="removeFromCart(item.id)" class="text-red-600 hover:underline">
              Remover
            </button>
          </td>
        </tr>
      </tbody>
    </table>
    <div v-if="items.length > 0" class="text-right font-bold text-lg">
      Total: ${{ totalPrice }}
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useCartStore } from '../store/cart';

const cartStore = useCartStore();
const items = computed(() => cartStore.items);
const totalPrice = computed(() => cartStore.totalPrice);

function removeFromCart(id) {
  cartStore.removeFromCart(id);
}

function updateQuantity(id, qty) {
  cartStore.updateQuantity(id, qty);
}
</script>
